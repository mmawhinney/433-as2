#ifndef _FILE_ACCESSOR_H_
#define _FILE_ACCESSOR_H_

void fileAccessor_enableI2cBus();
void fileAccessor_getReading(int *a2dReading);
void fileAccessor_enableCape();

#endif