#ifndef _PRIME_COUNT_DISPLAY_H_
#define _PRIME_COUNT_DISPLAY_H_


void* primeCountDisplay_launchThread(void* args);

#endif